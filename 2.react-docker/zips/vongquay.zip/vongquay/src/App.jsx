//* LIB
import React from "react";

//* IMPORT
import "./App.css";
import { rewards } from "./datas/rewards";
import { keyLocal } from "./constants/key";

const App = () => {
  const [spinTransform, setSpinTransform] = React.useState("rotate(0deg)");
  const [check, __] = React.useState(localStorage.getItem(keyLocal));
  const [active, setActive] = React.useState(false);
  const [checkname, setCheckname] = React.useState("");
  const [spined, setSpined] = React.useState("");
  const [formData, setFormData] = React.useState({
    name: "",
    phone: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const submitToGoogleForm = () => {
    const { name, phone } = formData;
    const checkInput = name && phone && spined;
    if (checkInput) {
      const formUrl = `https://docs.google.com/forms/d/e/${process.env.KEY_GOOGLE_FORM}/formResponse`;

      const formData = {
        "entry.2139414009": name,
        "entry.1577024686": phone,
        "entry.92846706": spined,
      };

      try {
        fetch(formUrl, {
          method: "POST",
          mode: "no-cors",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams(formData),
        });

        document
          .querySelector(".spin_form_container")
          .classList.remove("active");
        setTimeout(() => {
          alert(
            "Thành công, đến trang chủ để xem về chương trình học phù hợp ngay"
          );
          window.location.href = "https://profile-forme.com";
        }, 500);
      } catch (error) {
        console.error("Error submitting form:", error);
      }
    } else {
      alert("Vui lòng nhập đầy đủ thông tin");
    }
  };

  const handleSpinner = () => {
    const random = Math.floor(Math.random() * 100);
    let rewardIndex;
    let rotationDegree;
    let localStorageItem;

    switch (true) {
      case random < 5:
        rewardIndex = 0;
        rotationDegree = 1496;
        localStorageItem = "jjt48329139jffeji23912u3u213u218jf933080";
        break;
      case random < 30:
        rewardIndex = 1;
        rotationDegree = 1620;
        localStorageItem = "jjt48329139jffeji23912u3u213u218jf933181";
        break;
      case random < 60:
        rewardIndex = 2;
        rotationDegree = 1672;
        localStorageItem = "jjt48329139jffeji23912u3u213u218jf933282";
        break;
      case random < 80:
        rewardIndex = 3;
        rotationDegree = 1797;
        localStorageItem = "jjt48329139jffeji23912u3u213u218jf933282";
        break;
      default:
        rewardIndex = 4;
        rotationDegree = 1552;
        localStorageItem = "jjt48329139jffeji23912u3u213u218jf933383";
    }

    setSpined(rewards[rewardIndex]);
    setSpinTransform(`rotate(${rotationDegree}deg)`);
    localStorage.setItem(keyLocal, localStorageItem);
  };

  React.useEffect(() => {
    if (spined) {
      setTimeout(() => {
        document.querySelector(
          ".spin_form_title h2"
        ).innerHTML = `Bạn nhận được <br/> ${spined}`;
        document.querySelector(".spin_form_container").classList.add("active");
      }, 5500);
    }
  }, [spined]);

  React.useEffect(() => {
    const spinBtn = document.querySelector(".spiner_btn");
    if (check) {
      spinBtn.style.pointerEvents = "none";
      setActive(true);
      switch (check) {
        case "jjt48329139jffeji23912u3u213u218jf933080":
          setCheckname("Macbook Air M2!!!");
          break;
        case "jjt48329139jffeji23912u3u213u218jf933181":
          setCheckname("Voucher 500-CHF");
          break;
        case "jjt48329139jffeji23912u3u213u218jf933282":
          setCheckname("Voucher 200-CHF");
          break;
        case "jjt48329139jffeji23912u3u213u218jf933383":
          setCheckname("Voucher 300-CHF");
          break;
        default:
          console.error("Invalid check value:", check);
      }
      const spinForm = document.querySelector(
        ".spin_form_container .spin_form"
      );
      spinForm.innerHTML = `
        <div class="spin_form_title">
          <img src="https://ideas.edu.vn/wp-content/uploads/2024/02/Voucher-giam-hoc-phi-500-CHF-2.png" />
          <h2>${checkname}</h2>
          <a href="https://profile-forme.com">Nhận lộc ngay</a>
        </div>`;
    }
  }, [check]);

  console.log(process.env.KEY_GOOGLE_FORM);

  return (
    <React.Fragment>
      <div className="spiner_container">
        <img
          src="https://ideas.edu.vn/wp-content/uploads/2024/02/CHF-6.png"
          alt=""
          className="spiner"
          style={{ transform: spinTransform }}
        />
        <img
          src="https://ideas.edu.vn/wp-content/uploads/2024/02/CHF-5.png"
          alt=""
          className="spiner_btn"
          onClick={handleSpinner}
        />
      </div>

      <form className={`spin_form_container ${active ? "active" : ""}`}>
        <div className="spin_form">
          <div className="spin_form_title">
            <img
              src="https://ideas.edu.vn/wp-content/uploads/2024/02/Voucher-giam-hoc-phi-500-CHF-2.png"
              alt=""
            />
            <p className="spin_form_p">Tuyệt vời!!!</p>
            <h2></h2>
          </div>
          <div className="spin_form_content">
            <div className="spin_form_input">
              <p>Họ và tên</p>
              <input
                required
                type="text"
                placeholder=""
                id="nameI"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
              />
            </div>
            <div className="spin_form_input">
              <p>Số điện thoại</p>
              <input
                required
                type="phone"
                placeholder=""
                id="phoneI"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
              />
            </div>
            <div className="spin_form_btn">
              <a onClick={submitToGoogleForm}>Xác nhận</a>
            </div>
          </div>
        </div>
        <div className="spin_overlay"></div>
      </form>
    </React.Fragment>
  );
};

export default App;
