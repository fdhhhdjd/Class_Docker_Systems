export const rewards = [
  "Macbook Air M2",
  "Voucher 500-CHF",
  "Voucher 300-CHF",
  "Voucher 200-CHF",
  "Voucher 100-CHF", // Khách kêu quay là trúng nên ko thêm cái giải quay hụt
];
